# encoding: utf-8
# module imageop
# from (built-in)
# by generator 1.147
# no doc
# no imports

# functions

def crop(*args, **kwargs): # real signature unknown
    pass

def dither2grey2(*args, **kwargs): # real signature unknown
    pass

def dither2mono(*args, **kwargs): # real signature unknown
    pass

def grey22grey(*args, **kwargs): # real signature unknown
    pass

def grey2grey2(*args, **kwargs): # real signature unknown
    pass

def grey2grey4(*args, **kwargs): # real signature unknown
    pass

def grey2mono(*args, **kwargs): # real signature unknown
    pass

def grey2rgb(*args, **kwargs): # real signature unknown
    pass

def grey42grey(*args, **kwargs): # real signature unknown
    pass

def mono2grey(*args, **kwargs): # real signature unknown
    pass

def rgb2grey(*args, **kwargs): # real signature unknown
    pass

def rgb2rgb8(*args, **kwargs): # real signature unknown
    pass

def rgb82rgb(*args, **kwargs): # real signature unknown
    pass

def scale(*args, **kwargs): # real signature unknown
    pass

def tovideo(*args, **kwargs): # real signature unknown
    pass

# classes

class error(Exception):
    # no doc
    def __init__(self, *args, **kwargs): # real signature unknown
        pass

    __weakref__ = property(lambda self: object(), lambda self, v: None, lambda self: None)  # default
    """list of weak references to the object (if defined)"""



