# encoding: utf-8
# module _codecs_cn
# from (built-in)
# by generator 1.147
# no doc
# no imports

# functions

def getcodec(*args, **kwargs): # real signature unknown
    """  """
    pass

# no classes
# variables with complex values

__map_gb18030ext = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x0000000004CB16F0>'

__map_gb2312 = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x0000000004CB1420>'

__map_gbcommon = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x0000000004CB15D0>'

__map_gbkext = None # (!) real value is '<capsule object "multibytecodec.__map_*" at 0x0000000004CB1630>'

