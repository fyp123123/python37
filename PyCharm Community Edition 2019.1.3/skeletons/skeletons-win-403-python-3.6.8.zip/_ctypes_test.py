# encoding: utf-8
# module _ctypes_test
# from (pre-generated)
# by generator 1.147
# no doc
# no imports

# functions

def func(*args, **kwargs): # real signature unknown
    pass

def func_si(*args, **kwargs): # real signature unknown
    pass

# no classes
# variables with complex values

__loader__ = None # (!) real value is '<_frozen_importlib_external.ExtensionFileLoader object at 0x0000015BCA690588>'

__spec__ = None # (!) real value is "ModuleSpec(name='_ctypes_test', loader=<_frozen_importlib_external.ExtensionFileLoader object at 0x0000015BCA690588>, origin='C:\\\\BuildAgent\\\\system\\\\.persistent_cache\\\\pycharm\\\\pythons4skeletons\\\\python36\\\\DLLs\\\\_ctypes_test.pyd')"

